attachments_for_simplecalendar
==============================

Attachments plugin for SimpleCalendar (for Joomla)

This plugin allows users to add attachments to SimpleCalendar items in Joomla.

By Fabrizio Albonico, software@albonico.ch

For License/Copying information, please see the file LICENSE.txt

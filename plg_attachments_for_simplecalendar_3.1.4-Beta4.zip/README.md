attachments_for_simplecalendar
==============================

WARNING: This version will only work with Attachments 3.1.4-Beta4 or later!

Attachments plugin for SimpleCalendar (for Joomla)

This plugin allows users to add attachments to SimpleCalendar items in Joomla.

By Fabrizio Albonico, software@albonico.ch

For License/Copying information, please see the file LICENSE.txt
